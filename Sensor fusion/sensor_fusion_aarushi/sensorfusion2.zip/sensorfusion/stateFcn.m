function x_pred = stateFcn(x, u)
    % u = omega from gyroscope
    dt = 0.01; % or your simulation step time
    x_pred = x + u * dt;
end