function z = measFcn(x)
    % Measurement is directly the state
    z = x;
end