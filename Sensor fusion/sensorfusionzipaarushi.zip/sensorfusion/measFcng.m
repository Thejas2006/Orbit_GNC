function z = measFcng(x)
    z = x;  % predicted measurement is just the state
end
