function A = stateJacobianAdapter(x, u, dt)
    A =stateJacobianFcn(x, u); 
end