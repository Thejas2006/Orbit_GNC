function H = measJacobianFcng(x)
    H = eye(3);  % dz/dx is identity
end